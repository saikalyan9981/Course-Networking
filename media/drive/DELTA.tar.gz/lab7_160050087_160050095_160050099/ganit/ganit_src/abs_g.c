#include "../ganit.h"

/* Definition of double _abs(double a); in this file */

double _abs(double a){
	if (a>=0) return a;
	else return (-1 * a);
}
