#include "../ganit.h"
#include <stdlib.h>
#include <stdbool.h>
/* Definition of double isPrime(double a); in this file */
// You must cast 'a' to int in the body.
int modexp(int a, int b, int c){
	int sp=1;
	if ((a==1)||(b==0)) return sp;
	else {
		if ((b%2)==0){
			int t= modexp(a,b/2,c),res;
			res = (t*t)%c;
			return res;
		}
		else {
			int t= modexp(a,b/2,c),res;
			res=(t*t*a)%c;
			return res;
		}
	}
}
double isPrime(double b){
	int a=(int) b;
	if (a==1 || a<0) return 0;
	int r,c;
	int i,n=30;
	bool res=1;
	for(i=0;i<n;i++){
		r= rand()%(a-1) +1;
		c= modexp(r,(a-1),a);
		res=res&&(c==1);
		if (! res) return 0.0;
	}
	if (! res) return 0.0;
	else return 1.0;
}