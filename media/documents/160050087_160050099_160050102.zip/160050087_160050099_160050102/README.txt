Instructions:
Programs are written in MATLAB.
1)first two questions are written in q1,2.m 
2)Third question is written in q3.m
3)Fourth question is written in four parts, q4a.m, q4b.m, q4c.m and q4d.m 
4)Fifth question is wriiten in q5.m and the required audio file is also included in this folder.
5)Observations are written as comments in the respective matlab files.
6)The functions of filters required in the assignment are written as filter1.m, filter2.m, filter3.m
7)The graphs or audios  required are generated on running the programs.