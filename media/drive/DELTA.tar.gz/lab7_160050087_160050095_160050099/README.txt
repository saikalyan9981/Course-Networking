
PROBELM1:

Done by: all

To clean, use :-     make clean
we haven't included clean in all because make will recompile everything everytime, which defeats the purpose of make.
We have replaced rm with $(RM) as rm throws an error when some of the files are not present.

=================================================================================================================================================

Extra Questions:
1. make a (trivial) change to one of the functions in `./ganit_src`. How many things should be re-built? How many does your Makefile re-build?
ans. Here, it should rebuild 3 files. It does rebuild 3 files. the corresponding object file, the library, and the final executable.
	If we used the .o file instead of the library, it would only rebuild 2 files.

2. How many rebuilds if you make a change in `ganit.h`?
ans. 7

3. How many rebuilds if you comment out a few entries in `struct init_funcs arith_fncts[]`?
ans. 5 calc.tab.c, calc.tab.h, calc.tab.o, lexer.o, calc.	

4. How many rebuilds if you do (3) then (1) and then run `make`?
ans. 7 previous 5 + the corresponding .o file of the function, the library file.

5. Find out how to list the contents of the archive.
ans. the command:-       ar -t libgit.a

6. Since `libganit.a` is an archive after-all, can it be decompressed into constituent object files?
ans. NO
=================================================================================================================================================

References:
https://www.gnu.org/software/make/manual/    - official gnu make documentation, referred to this for almost everything.







__________________________________________________________________________________________________________________________________________________
__________________________________________________________________________________________________________________________________________________




PROBLEM2:

done by all

citation: 
https://www.stack.nl/~dimitri/doxygen/manual/docblocks.html#pythonblocks for commenting in python

java part:
how to run:
------------------
go to
problem2-> LinkList.java

commands in terminal:
--------------
1. doxygen linklistconfig
2. cd latex && make

--------------this generates required pdf named "refman.pdf" in latex folder

python part:
how to run:
------------------
go to
problem2->python_problem

commands in terminal:
--------------
1. doxygen pythonconfig
2. cd latex && make

--------------this generates required pdf named "refman.pdf" in latex folder

