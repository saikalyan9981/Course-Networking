/**
    * \author TeamDelta
    * \version 1.0
    * \date 21-7-2017
    * \bug NO bug!!!
    * \mainpage LinkedList
   * \section INTRODUCTION
* This program helps you to implement Deque class
*/ 

/**
* LinkList class and its functions
*/
public class LinkList<T> {
 
    private Node<T> front;/**< front element of deque. */ 
    private Node<T> rear;/**< rear element of deque. */
    
    /** 
    * @param item
    *  Template variable
    * \brief
    * Inserting new item at the front
    */ 
    public void insertFront(T item){
        //add element at the beginning of the queue
        System.out.println("adding at front: "+item);
        Node<T> nd = new Node<T>();
        nd.setValue(item);
        nd.setNext(front);
        if(front != null) front.setPrev(nd);
        if(front == null) rear = nd;
        front = nd;
    }
    /** 
    * @param item
    *  Template variable
    * \brief
    * Inserting new item at the rear
    */ 
    public void insertRear(T item){
        //add element at the end of the queue
        System.out.println("adding at rear: "+item);
        Node<T> nd = new Node<T>();
        nd.setValue(item);
        nd.setPrev(rear);
        if(rear != null) rear.setNext(nd);
        if(rear == null) front = nd;
         
        rear = nd;
    }
    /** 
    * \brief Removing item at the front
    */ 
    public void removeFront(){
        if(front == null){
            System.out.println("Deque underflow!! unable to remove.");
            return;
        }
        //remove an item from the beginning of the queue
        Node<T> tmpFront = front.getNext();
        if(tmpFront != null) tmpFront.setPrev(null);
        if(tmpFront == null) rear = null;
        System.out.println("removed from front: "+front.getValue());
        front = tmpFront;
    }
    /** 
    * \brief Removing item at the rear
    */ 
    public void removeRear(){
        if(rear == null){
            System.out.println("Deque underflow!! unable to remove.");
            return;
        }
        //remove an item from the beginning of the queue
        Node<T> tmpRear = rear.getPrev();
        if(tmpRear != null) tmpRear.setNext(null);
        if(tmpRear == null) front = null;
        System.out.println("removed from rear: "+rear.getValue());
        rear = tmpRear;
    }
    /**
    * main function in which deque is intialised
    */
    public static void main(String a[]){
        LinkList<Integer> deque = new LinkList<Integer>(); 
        deque.insertFront(34);
        deque.insertFront(67);
        deque.insertFront(29);
        deque.insertFront(765);
        deque.removeFront();
        deque.removeFront();
        deque.removeFront();
        deque.insertRear(43);
        deque.insertRear(83);
        deque.insertRear(84);
        deque.insertRear(546);
        deque.insertRear(356);
        deque.removeRear();
        deque.removeRear();
        deque.removeRear();
        deque.removeRear();
        deque.removeFront();
        deque.removeFront();
        deque.removeFront();
    }
}
/**
* Node class 
**/ 
class Node<T>{
     
    private Node<T> prev;/**< previous node **/
    private Node<T> next;/**< next node **/
    private T value;/**< value of node **/
    
    /**
    * @return
    * previous node
    **/ 
    public Node<T> getPrev() {
        return prev;
    }
    /**
    * @param 
    *prev
    * a Node
    *\brief
    * sets previous node.
    * @return
    * Void
    **/ 
    public void setPrev(Node<T> prev) {
        this.prev = prev;
    }
    /**
    * @return
    * next node
    **/ 
    public Node<T> getNext() {
        return next;
    }
    /**
    * @param 
    * prev
    * a Node
    *\brief
    * sets Next node.
    * @return
    * Void
    **/ 
    public void setNext(Node<T> next) {
        this.next = next;
    }

    /**
    * @return
    * Value of node
    **/ 
    public T getValue() {
        return value;
    }

    /**
    * @param prev
    * a Node
    * \brief 
    * sets value of node.
    * @return
    * Void
    **/ 
    public void setValue(T value) {
        this.value = value;
    }
}