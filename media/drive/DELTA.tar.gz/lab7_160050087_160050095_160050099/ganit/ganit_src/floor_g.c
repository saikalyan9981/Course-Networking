#include "../ganit.h"

/* Definition of double _floor(double a); in this file */
double _floor(double a){
	return floor(a);
}