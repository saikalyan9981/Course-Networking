#include "../ganit.h"

/* Definition of double _ceil(double a); in this file */
double _ceil(double a){
	return ceil(a);
}