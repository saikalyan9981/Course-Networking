#include "../ganit.h"

/* Definition of double factorial(double a); in this file */
// You must cast 'a' as int in the body.
double factorial(double a){
	int n= (int) a;
	int res=1;
	if (n<0) return -1;
	else if (n==0 || n==1) return 1;
	else {
		for(int i=1;i<=n;i++){
		res*=i;
		}
		return res;
	}
}